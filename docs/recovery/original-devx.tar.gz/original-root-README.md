# AIRE — AI-Assisted Reverse Engineering (Ghidra Extension)

**Author:** Laurene Robinson
**Module:** AIRE  (`aire-ghidra-extension`)
**Target host:** Ghidra 12.0.1 PUBLIC
**Language / runtime:** Java 21
**Backend:** Local model server (Ollama)

This README explains exactly what tools are needed, where to get them,
and how to open this source tree in the development environment that
the project is actually built against.

---

## 1. What this project is

AIRE is a Ghidra extension that helps analysts rename stripped or
ambiguous functions during reverse engineering. The extension extracts
decompiler output and structural program features, packages that
evidence into a model-ready prompt, queries a locally hosted Ollama
model, post-processes the candidates with confidence-aware filtering,
and presents the surviving suggestions in a dockable Swing panel
inside Ghidra. The analyst stays in control: nothing is renamed until
they click **Apply**.

This source tree is the **canonical Ghidra extension module**
(`aire-ghidra-extension/`). It is the layout Ghidra's
`buildExtension` Gradle task expects.

---

## 2. Source-tree layout (do not rearrange)

The structure below is the layout Ghidra's extension module spec
requires. Ghidra, Gradle, the IDE, and the packaging script all assume
these exact paths, so the tree should be kept intact.

```
aire-ghidra-extension/
├── Module.manifest              Ghidra module marker (must exist, may be empty)
├── extension.properties         Name, version, author, description (read by Ghidra at install)
├── build.gradle                 Gradle build file consumed by Ghidra's buildExtension task
├── buildTemplate.gradle         Ghidra-shipped reference template (kept for parity)
├── README.md                    This file
│
├── src/                         All hand-written sources live here
│   └── main/
│       ├── java/aire/           Java packages (see §3)
│       │   ├── AirePlugin.java
│       │   ├── AirePluginPackage.java
│       │   ├── AireSuggestionsProvider.java
│       │   ├── config/                (reserved for runtime config classes)
│       │   ├── model/                 Data objects (NameSuggestion, SymbolContext, …)
│       │   ├── services/              ContextExtractor, OllamaSuggestionProvider, SuggestionProvider
│       │   └── ui/                    Swing table model + row objects
│       ├── help/help/                 Ghidra help-system TOC stub
│       └── resources/                 Icons / images packaged into the jar
│
├── data/                        Sleigh / language stubs (kept for module-spec compliance)
├── ghidra_scripts/              Module-local Ghidra scripts (currently empty)
├── lib/                         Third-party jars bundled into the extension
│   └── gson-2.10.1.jar          JSON parsing for the Ollama HTTP responses
├── os/                          Per-OS native bin dirs (linux_x86_64, mac_x86_64, win_x86_64)
└── scripts/
    └── build_extension.sh       Manual packaging script (alternative to Gradle)
```

What is **not** in this zip and why:

* `build/`  — Gradle output. Regenerated on every build.
* `.gradle/` — Local Gradle cache. Per-machine.
* `dist/`  — Previously packaged `.zip` artifacts. Reproducible from source.
* `.git/`  — Repository metadata. Not part of the buildable source.

---

## 3. What each Java package does

| Package | Role |
| --- | --- |
| `aire` | Plugin entry point (`AirePlugin`), package descriptor, and the dockable component (`AireSuggestionsProvider`). |
| `aire.model` | Plain data carriers: `NameSuggestion`, `SymbolContext`, `SuggestionStatus`. These are what flow between the extractor, the backend, and the UI. |
| `aire.services` | `ContextExtractor` (pulls evidence from Ghidra), `SuggestionProvider` (interface), `OllamaSuggestionProvider` (HTTP client + prompt + parser + confidence post-processing). |
| `aire.ui` | Swing table model (`SuggestionsTableModel`) and per-row state (`SuggestionRow`). |
| `aire.config` | Reserved for future config / settings classes. |

---

## 4. Required tools and where to get them

All four of these are required to build and run AIRE from source. The
versions listed are the ones the project is developed and tested
against.

### 4.1 Ghidra 12.0.1 PUBLIC  (the host application)

* **What it is:** The reverse-engineering platform AIRE plugs into.
* **Where to get it:** <https://github.com/NationalSecurityAgency/ghidra/releases>
  (official release page) or <https://ghidra-sre.org>.
* **Which file:** `ghidra_12.0.1_PUBLIC_*.zip`.
* **Where to install:** Anywhere. The build expects the path in the
  environment variable `GHIDRA_INSTALL_DIR`. Linux convention used by
  `scripts/build_extension.sh` is `/opt/ghidra_12.0.1_PUBLIC`.

### 4.2 Java JDK 21  (the toolchain)

* **What it is:** Compiler + runtime. Ghidra 12.0.1 runs on Java 21.
* **Where to get it:** <https://adoptium.net/temurin/releases/?version=21>
  (Eclipse Temurin — recommended, free, LTS) or
  <https://www.oracle.com/java/technologies/downloads/#java21> (Oracle JDK 21).
* **How to verify:** `java -version` should print `21.x.x`.
* **JAVA_HOME:** Point it at the JDK 21 install root. Ghidra and
  Gradle both read it.

### 4.3 Gradle  (the build tool)

* **What it is:** Drives the `buildExtension` task that produces the
  installable extension zip.
* **Important:** Use the **exact Gradle version** Ghidra asks for. Read
  `<GHIDRA_INSTALL_DIR>/Ghidra/application.properties` and look for
  `application.gradle.version=…`. Use that version.
* **Where to get it:** <https://gradle.org/releases/>. Pick the version
  noted above. SDKMAN! (<https://sdkman.io>) is a convenient way to
  switch between Gradle versions on Linux/macOS.
* **How to verify:** `gradle --version` prints the version, the JVM it
  is running on (must be JDK 21), and the OS.

### 4.4 Ollama  (the local model backend)

* **What it is:** Local LLM server that AIRE talks to over HTTP. Runs
  fully offline on the analyst machine, which is intentional — binaries
  under analysis never leave the host.
* **Where to get it:** <https://ollama.com/download>
* **Default endpoint:** `http://localhost:11434` (this is the default
  `AirePlugin` falls back to).
* **Default model:** `gemma3:4b` (the default `AirePlugin` falls back
  to). Pull it once with:
  ```
  ollama pull gemma3:4b
  ```
* **Override either default** at runtime with environment variables
  before launching Ghidra:
  ```
  export AIRE_OLLAMA_URL="http://localhost:11434"
  export AIRE_OLLAMA_MODEL="gemma3:4b"
  ```
  …or with JVM system properties: `-Daire.ollama.url=…`,
  `-Daire.ollama.model=…`.

### 4.5 An IDE  (recommended, not strictly required)

You can build and run AIRE with just the JDK + Gradle + the bundled
`scripts/build_extension.sh`. To **edit** the source comfortably with
working Ghidra-API autocomplete, use one of:

* **Eclipse + GhidraDev plugin** — official path. Install Eclipse
  (<https://www.eclipse.org/downloads/>), then in Ghidra go to
  *File → Install Extensions → GhidraDev* and follow the prompt to
  install GhidraDev into Eclipse. GhidraDev wires up the Ghidra API
  classpath and adds *Link Ghidra* / *New → Ghidra Module Project*.
  Reference: `<GHIDRA_INSTALL_DIR>/Extensions/Eclipse/GhidraDev/GhidraDev_README.html`.
* **IntelliJ IDEA Community** — <https://www.jetbrains.com/idea/download/>.
  Open the project as a Gradle project (point it at this folder's
  `build.gradle`).

### 4.6 Operating system

The project is developed on **Linux** (Kali). It is also expected to
build on macOS. Windows works for running Ghidra and the extension,
but `scripts/build_extension.sh` is bash and assumes a Unix-like shell;
on Windows use the Gradle path (§5.2) instead.

---

## 5. How to open and build the project

### 5.1 One-time environment setup

```bash
# 1. Install Ghidra 12.0.1 PUBLIC, then point AIRE at it:
export GHIDRA_INSTALL_DIR=/opt/ghidra_12.0.1_PUBLIC

# 2. Make sure Java 21 is the active JDK:
export JAVA_HOME=/path/to/jdk-21
java -version    # must say 21

# 3. Start Ollama and pull the default model:
ollama serve &        # if it isn't already running as a service
ollama pull gemma3:4b
```

### 5.2 Build with Gradle  (recommended, cross-platform)

From the `aire-ghidra-extension/` directory:

```bash
gradle -PGHIDRA_INSTALL_DIR=$GHIDRA_INSTALL_DIR buildExtension
```

The packaged extension lands in `dist/` as
`ghidra_12.0.1_PUBLIC_<date>_aire-ghidra-extension.zip`.

### 5.3 Build with the helper script  (Linux / macOS)

```bash
./scripts/build_extension.sh
```

This does the same thing without invoking Gradle: compiles the Java
sources against Ghidra's jars, assembles the module jar plus a
`-src.zip`, copies the extension metadata, and writes the result to
`dist/`. It honors `GHIDRA_INSTALL_DIR` and accepts an optional date
stamp argument.

### 5.4 Open in Eclipse (GhidraDev)

1. *File → New → Other… → Ghidra → Ghidra Module Project*  — or  *Import…
   → General → Existing Projects into Workspace* and pick this folder.
2. Right-click the project → *GhidraDev → Link Ghidra…* and select
   your `GHIDRA_INSTALL_DIR`. This adds the Ghidra API to the
   classpath.
3. The `lib/gson-2.10.1.jar` is already on disk; add it to the project
   build path if Eclipse does not pick it up automatically.

### 5.5 Open in IntelliJ IDEA

1. *Open* → select the `aire-ghidra-extension/` folder.
2. IntelliJ detects `build.gradle` and imports as a Gradle project.
3. Set the project SDK to JDK 21 (*File → Project Structure → Project*).
4. Set `GHIDRA_INSTALL_DIR` in *Run/Debug Configurations → Environment
   variables* before invoking `buildExtension`.

### 5.6 Install the built extension into Ghidra

1. Launch Ghidra.
2. *File → Install Extensions → +* and pick the zip from `dist/`.
3. Restart Ghidra when prompted.
4. In a tool (e.g. CodeBrowser): *File → Configure → Configure All
   Plugins…* and enable **A.I.R.E**.
5. The dockable **A.I.R.E Suggestions** panel appears at the bottom.
   Open a binary, click *Refresh*, select a function, click *Suggest*.

---

## 6. Quick troubleshooting

| Symptom | Likely cause |
| --- | --- |
| `Backend: unavailable` in the panel header | Ollama is not running, or `AIRE_OLLAMA_URL` points to the wrong host/port. |
| `Model missing` banner after clicking Suggest | The configured model (default `gemma3:4b`) has not been `ollama pull`'d. |
| Gradle complains about an unsupported version | Gradle version does not match `application.gradle.version` in Ghidra's `application.properties`. Switch Gradle versions. |
| `javac` errors about Ghidra classes | `GHIDRA_INSTALL_DIR` is unset or wrong, so Ghidra's jars are not on the classpath. |
| Extension loads but no panel | The plugin is not enabled in *Configure All Plugins*. |

---

## 7. Project metadata at a glance

* `extension.properties` — name `AIRE`, version `0.1`, author
  *Laurene Robinson*. Ghidra reads this verbatim when installing.
* `Module.manifest` — present (intentionally empty). Ghidra requires
  the file to exist for the directory to be recognized as a module.
* `lib/gson-2.10.1.jar` — bundled at build time. Used by
  `OllamaSuggestionProvider` to parse Ollama's JSON responses.
