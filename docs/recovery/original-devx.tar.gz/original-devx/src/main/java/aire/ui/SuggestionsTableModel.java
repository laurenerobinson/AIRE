package aire.ui;

import javax.swing.table.AbstractTableModel;
import java.util.ArrayList;
import java.util.List;

public class SuggestionsTableModel extends AbstractTableModel {

    private final String[] cols = {"Function", "Entry"};
    private final List<SuggestionRow> rows = new ArrayList<>();

    public void setRows(List<SuggestionRow> r) {
        rows.clear();
        rows.addAll(r);
        fireTableDataChanged();
    }

    public SuggestionRow getRow(int idx) {
        return (idx >= 0 && idx < rows.size()) ? rows.get(idx) : null;
    }

    @Override public int getRowCount() { return rows.size(); }
    @Override public int getColumnCount() { return cols.length; }
    @Override public String getColumnName(int col) { return cols[col]; }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        SuggestionRow row = rows.get(rowIndex);
        switch (columnIndex) {
            case 0: return row.function.getName();
            case 1: return row.function.getEntryPoint().toString();
            default: return "";
        }
    }
}
