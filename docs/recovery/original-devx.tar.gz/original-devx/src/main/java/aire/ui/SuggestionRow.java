package aire.ui;

import aire.model.NameSuggestion;
import aire.model.SuggestionStatus;
import ghidra.program.model.listing.Function;

import java.util.ArrayList;
import java.util.List;

public class SuggestionRow {
    public final Function function;
    public List<NameSuggestion> suggestions = new ArrayList<>();
    public SuggestionStatus status = SuggestionStatus.NEW;

    /**
     * Index into {@link #suggestions} that the user selected in the UI.
     * -1 means nothing selected yet.
     */
    public int selectedSuggestionIndex = -1;

    public SuggestionRow(Function function) {
        this.function = function;
    }

    public String getTopName() {
        return suggestions.isEmpty() ? "" : suggestions.get(0).name;
    }

    public String getSelectedNameOrTop() {
        if (suggestions.isEmpty()) return "";
        if (selectedSuggestionIndex >= 0 && selectedSuggestionIndex < suggestions.size()) {
            return suggestions.get(selectedSuggestionIndex).name;
        }
        return suggestions.get(0).name;
    }

    public NameSuggestion getSelectedSuggestionOrTop() {
        if (suggestions.isEmpty()) return null;
        if (selectedSuggestionIndex >= 0 && selectedSuggestionIndex < suggestions.size()) {
            return suggestions.get(selectedSuggestionIndex);
        }
        return suggestions.get(0);
    }

    public double getTopConfidence() {
        return suggestions.isEmpty() ? 0.0 : suggestions.get(0).confidence;
    }
}
