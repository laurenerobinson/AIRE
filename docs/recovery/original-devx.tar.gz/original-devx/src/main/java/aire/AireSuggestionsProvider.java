package aire;

import aire.model.NameSuggestion;
import aire.model.SuggestionStatus;
import aire.model.SymbolContext;
import aire.services.ContextExtractor;
import aire.services.SuggestionProvider;
import aire.ui.SuggestionRow;
import aire.ui.SuggestionsTableModel;
import ghidra.app.services.ProgramManager;
import ghidra.framework.plugintool.ComponentProviderAdapter;
import ghidra.framework.plugintool.PluginTool;
import ghidra.program.model.listing.*;
import ghidra.program.model.symbol.SourceType;
import ghidra.util.Msg;
import ghidra.util.task.Task;
import ghidra.util.task.TaskMonitor;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class AireSuggestionsProvider extends ComponentProviderAdapter {

    private final PluginTool tool;
    private final ContextExtractor extractor;
    private final SuggestionProvider suggestionProvider;

    private final JPanel panel = new JPanel(new BorderLayout());
    private final SuggestionsTableModel tableModel = new SuggestionsTableModel();
    private final JTable table = new JTable(tableModel);

    private final JButton refreshBtn = new JButton("Refresh");
    private final JButton suggestBtn = new JButton("Suggest");
    private final JButton applyBtn = new JButton("Apply");

    private final JLabel statusLabel = new JLabel("Status: (not checked yet)");
    private final JTextArea details = new JTextArea();

    public AireSuggestionsProvider(PluginTool tool,
                                   ContextExtractor extractor,
                                   SuggestionProvider suggestionProvider) {
        super(tool, "A.I.R.E Suggestions", "AIRE");

        this.tool = tool;
        this.extractor = extractor;
        this.suggestionProvider = suggestionProvider;

        buildUI();
        setVisible(true);
    }

    private void buildUI() {
        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT));
        top.add(refreshBtn);
        top.add(suggestBtn);
        top.add(applyBtn);

        statusLabel.setText("Status: " + suggestionProvider.getStatus());
        top.add(Box.createHorizontalStrut(16));
        top.add(statusLabel);
        panel.add(top, BorderLayout.NORTH);

        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane tableScroll = new JScrollPane(table);

        details.setEditable(false);
        details.setRows(8);
        JScrollPane detailScroll = new JScrollPane(details);

        JSplitPane split = new JSplitPane(JSplitPane.VERTICAL_SPLIT, tableScroll, detailScroll);
        split.setResizeWeight(0.7);
        panel.add(split, BorderLayout.CENTER);

        refreshBtn.addActionListener(e -> refreshFunctions());
        suggestBtn.addActionListener(e -> suggestForSelected());
        applyBtn.addActionListener(e -> applySelectedTopSuggestion());

        table.getSelectionModel().addListSelectionListener(e -> {
            if (e.getValueIsAdjusting()) return;
            showSelectedDetails();
        });
    }

    @Override
    public JComponent getComponent() {
        return panel;
    }

    private Program getCurrentProgram() {
        ProgramManager pm = tool.getService(ProgramManager.class);
        if (pm == null) return null;
        return pm.getCurrentProgram();
    }

    private void refreshFunctions() {
        Program program = getCurrentProgram();
        if (program == null) {
            Msg.showInfo(this, tool.getToolFrame(), "A.I.R.E", "No program is open. Open a binary first.");
            return;
        }

        List<SuggestionRow> rows = new ArrayList<>();
        FunctionIterator it = program.getFunctionManager().getFunctions(true);

        int limit = 250;
        int count = 0;
        while (it.hasNext() && count < limit) {
            Function f = it.next();
            rows.add(new SuggestionRow(f));
            count++;
        }

        tableModel.setRows(rows);
        details.setText("Loaded " + rows.size() + " functions.\nSelect one and click Suggest.");
    }

    private void suggestForSelected() {
        int idx = table.getSelectedRow();
        SuggestionRow row = tableModel.getRow(idx);
        if (row == null) {
            Msg.showInfo(this, tool.getToolFrame(), "A.I.R.E", "Select a function row first.");
            return;
        }

        Program program = getCurrentProgram();
        if (program == null) {
            Msg.showInfo(this, tool.getToolFrame(), "A.I.R.E", "No program is open.");
            return;
        }

        details.setText("Generating suggestions using local LLM...\n(Confirm Ollama is running.)");

        Task task = new Task("A.I.R.E - Suggest Names", true, false, true) {
            @Override
            public void run(TaskMonitor monitor) {
                try {
                    monitor.setMessage("Extracting context...");
                    SymbolContext ctx = extractor.extract(program, row.function, monitor);

                    monitor.setMessage("Calling Ollama...");
                    List<NameSuggestion> suggestions = suggestionProvider.suggest(ctx);

                    SwingUtilities.invokeLater(() -> {
                        row.suggestions = suggestions;
                        row.status = SuggestionStatus.SUGGESTED;
                        tableModel.updateSuggestions(idx);
                        showSelectedDetails();
                    });

                } catch (Exception ex) {
                    SwingUtilities.invokeLater(() -> {
                        row.status = SuggestionStatus.ERROR;
                        tableModel.updateSuggestions(idx);
                        details.setText("ERROR generating suggestions:\n" + ex.getMessage());
                    });
                }
            }
        };

        tool.execute(task);
    }

    private void applySelectedTopSuggestion() {
        int idx = table.getSelectedRow();
        SuggestionRow row = tableModel.getRow(idx);
        if (row == null) {
            Msg.showInfo(this, tool.getToolFrame(), "A.I.R.E", "Select a function row first.");
            return;
        }

        String newName = row.getTopName();
        if (newName == null || newName.isBlank()) {
            Msg.showInfo(this, tool.getToolFrame(), "A.I.R.E", "No suggestion available. Click Suggest first.");
            return;
        }

        Program program = getCurrentProgram();
        if (program == null) {
            Msg.showInfo(this, tool.getToolFrame(), "A.I.R.E", "No program is open.");
            return;
        }

        int tx = program.startTransaction("A.I.R.E Apply Suggestion");
        try {
            row.function.setName(newName, SourceType.USER_DEFINED);
            program.endTransaction(tx, true);

            row.status = SuggestionStatus.APPLIED;
            tableModel.updateSuggestions(idx);

            Msg.showInfo(this, tool.getToolFrame(), "A.I.R.E", "Renamed function to: " + newName);
            showSelectedDetails();
        } catch (Exception ex) {
            program.endTransaction(tx, false);
            row.status = SuggestionStatus.ERROR;
            tableModel.updateSuggestions(idx);
            details.setText("ERROR applying rename:\n" + ex.getMessage());
        }
    }

    private void showSelectedDetails() {
        int idx = table.getSelectedRow();
        SuggestionRow row = tableModel.getRow(idx);
        if (row == null) {
            details.setText("Select a function row to view suggestions.");
            return;
        }

        StringBuilder sb = new StringBuilder();
        sb.append("Function: ").append(row.function.getName()).append("\n");
        sb.append("Entry: ").append(row.function.getEntryPoint()).append("\n");
        sb.append("Status: ").append(row.status).append("\n\n");

        if (row.suggestions.isEmpty()) {
            sb.append("No suggestions yet.\nClick Suggest to query the local LLM.");
        } else {
            sb.append("Top suggestions:\n");
            for (int i = 0; i < row.suggestions.size(); i++) {
                NameSuggestion s = row.suggestions.get(i);
                sb.append("  ").append(i + 1).append(") ")
                  .append(s.name)
                  .append(" (").append(String.format("%.2f", s.confidence)).append(")\n")
                  .append("     ").append(s.reason).append("\n");
            }
        }

        details.setText(sb.toString());
    }
}
