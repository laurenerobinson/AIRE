package aire.services;

import aire.model.SymbolContext;
import ghidra.app.decompiler.DecompInterface;
import ghidra.app.decompiler.DecompileOptions;
import ghidra.app.decompiler.DecompileResults;
import ghidra.program.model.address.AddressSetView;
import ghidra.program.model.block.BasicBlockModel;
import ghidra.program.model.block.CodeBlock;
import ghidra.program.model.block.CodeBlockIterator;
import ghidra.program.model.listing.Data;
import ghidra.program.model.listing.Function;
import ghidra.program.model.listing.Instruction;
import ghidra.program.model.listing.Listing;
import ghidra.program.model.listing.Program;
import ghidra.program.model.symbol.FlowType;
import ghidra.util.exception.CancelledException;
import ghidra.util.task.TaskMonitor;

import java.util.HashSet;
import java.util.Set;

public class ContextExtractor {

    private static final int MAX_DECOMPILE_MS = 2000;
    private static final int MAX_STRINGS = 8;
    private static final int MAX_CALLEES = 10;
    private static final int MAX_ASM_LINES = 20;
    private static final int MAX_DECOMP_CHARS = 4000;

    public SymbolContext extract(Program program, Function function, TaskMonitor monitor) {
        SymbolContext ctx = new SymbolContext();

        ctx.functionName = function.getName();
        ctx.entryPoint = function.getEntryPoint().toString();
        ctx.signature = function.getPrototypeString(false, false);

        AddressSetView body = function.getBody();
        Listing listing = program.getListing();

        ctx.decompiledCode = safeDecompile(program, function, monitor);
        ctx.assemblySnippet = buildAsmSnippet(listing, body, monitor);

        fillInstructionAndBranchCounts(listing, body, ctx, monitor);
        ctx.basicBlockCount = countBasicBlocks(program, body, monitor);

        extractReferencedStrings(listing, body, ctx, monitor);
        extractCallees(function, ctx, monitor);
        applyHeuristics(ctx);

        return ctx;
    }

    private String safeDecompile(Program program, Function function, TaskMonitor monitor) {
        DecompInterface decomp = new DecompInterface();
        try {
            DecompileOptions options = new DecompileOptions();
            decomp.setOptions(options);
            decomp.toggleCCode(true);
            decomp.toggleSyntaxTree(false);

            if (!decomp.openProgram(program)) {
                return "";
            }

            DecompileResults results = decomp.decompileFunction(function, MAX_DECOMPILE_MS, monitor);
            if (results == null || !results.decompileCompleted()) {
                return "";
            }

            String c = results.getDecompiledFunction().getC();
            if (c == null) {
                return "";
            }

            c = c.trim();
            if (c.length() > MAX_DECOMP_CHARS) {
                c = c.substring(0, MAX_DECOMP_CHARS) + "\n/* ... truncated ... */";
            }
            return c;
        } catch (Exception e) {
            return "";
        } finally {
            decomp.dispose();
        }
    }

    private String buildAsmSnippet(Listing listing, AddressSetView body, TaskMonitor monitor) {
        StringBuilder sb = new StringBuilder();
        int lines = 0;

        try {
            for (Instruction ins : listing.getInstructions(body, true)) {
                monitor.checkCancelled();

                sb.append(ins.getAddress())
                  .append(": ")
                  .append(ins.toString())
                  .append("\n");

                lines++;
                if (lines >= MAX_ASM_LINES) {
                    break;
                }
            }
        } catch (CancelledException e) {
        }

        return sb.toString().trim();
    }

    private void fillInstructionAndBranchCounts(Listing listing, AddressSetView body, SymbolContext ctx, TaskMonitor monitor) {
        int insnCount = 0;
        int branchCount = 0;
        int retCount = 0;

        try {
            for (Instruction ins : listing.getInstructions(body, true)) {
                monitor.checkCancelled();
                insnCount++;

                FlowType ft = ins.getFlowType();
                if (ft != null) {
                    if (ft.isJump() || ft.isConditional() || ft.isTerminal()) {
                        if (ft.isTerminal()) {
                            retCount++;
                        } else {
                            branchCount++;
                        }
                    }
                }
            }
        } catch (CancelledException e) {
        }

        ctx.instructionCount = insnCount;
        ctx.branchCount = branchCount;
        ctx.returnCount = retCount;
        ctx.loopCount = 0;
    }

    private int countBasicBlocks(Program program, AddressSetView body, TaskMonitor monitor) {
        try {
            BasicBlockModel bbm = new BasicBlockModel(program);
            CodeBlockIterator it = bbm.getCodeBlocksContaining(body, monitor);

            int count = 0;
            while (it.hasNext()) {
                monitor.checkCancelled();
                CodeBlock b = it.next();
                if (b != null) {
                    count++;
                }
            }
            return count;
        } catch (CancelledException e) {
            return 0;
        } catch (Exception e) {
            return 0;
        }
    }

    private void extractReferencedStrings(Listing listing, AddressSetView body, SymbolContext ctx, TaskMonitor monitor) {
        int added = 0;

        try {
            for (Data d : listing.getDefinedData(body, true)) {
                monitor.checkCancelled();
                if (added >= MAX_STRINGS) {
                    break;
                }

                Object v = null;
                try {
                    v = d.getValue();
                } catch (Exception ignored) {
                }

                String s = null;
                if (v instanceof String) {
                    s = (String) v;
                } else {
                    String rep = d.getDefaultValueRepresentation();
                    if (rep != null && rep.length() > 0 && looksLikeString(rep)) {
                        s = rep;
                    }
                }

                if (s != null) {
                    s = sanitizeString(s);
                    boolean exists = false;

                    for (String existing : ctx.referencedStrings) {
                        if (existing.equals(s)) {
                            exists = true;
                            break;
                        }
                    }

                    if (!s.isBlank() && !exists) {
                        ctx.referencedStrings.add(s);
                        added++;
                    }
                }
            }
        } catch (CancelledException e) {
        }
    }

    private boolean looksLikeString(String rep) {
        if (rep.length() < 3) {
            return false;
        }

        int printable = 0;
        for (int i = 0; i < rep.length(); i++) {
            char c = rep.charAt(i);
            if (c >= 32 && c <= 126) {
                printable++;
            }
        }

        double ratio = (rep.length() == 0) ? 0.0 : ((double) printable / (double) rep.length());
        return ratio > 0.85;
    }

    private String sanitizeString(String s) {
        s = s.replace("\n", " ").replace("\r", " ").trim();
        if (s.length() > 160) {
            s = s.substring(0, 160) + "...";
        }
        return s;
    }

    private void extractCallees(Function function, SymbolContext ctx, TaskMonitor monitor) {
        try {
            Set<String> names = new HashSet<>();

            for (Function callee : function.getCalledFunctions(monitor)) {
                monitor.checkCancelled();

                if (callee == null) {
                    continue;
                }

                String name = callee.getName();
                if (name == null || name.isBlank()) {
                    continue;
                }

                if (names.add(name)) {
                    ctx.callees.add(name);
                    if (ctx.callees.size() >= MAX_CALLEES) {
                        break;
                    }
                }
            }
        } catch (Exception ignored) {
        }
    }

    private void applyHeuristics(SymbolContext ctx) {
        String all = (ctx.decompiledCode == null ? "" : ctx.decompiledCode).toLowerCase();
        String asm = (ctx.assemblySnippet == null ? "" : ctx.assemblySnippet).toLowerCase();
        String calleeBlob = String.join(" ", ctx.callees).toLowerCase();
        String strBlob = String.join(" ", ctx.referencedStrings).toLowerCase();

        all = all + "\n" + asm + "\n" + calleeBlob + "\n" + strBlob;

        ctx.usesMemcpyLike = containsAny(all, "memcpy", "memmove", "bcopy");
        ctx.usesStrcmpLike = containsAny(all, "strcmp", "strncmp", "strcasecmp", "strncasecmp");
        ctx.usesMallocFreeLike = containsAny(all, "malloc", "calloc", "realloc", "free", "new", "delete");
        ctx.usesFileIOLike = containsAny(all, "fopen", "fread", "fwrite", "fclose", "open(", "read(", "write(", "lseek");
        ctx.usesNetworkIOLike = containsAny(all, "socket", "connect", "accept", "bind", "listen", "recv", "send", "getsockopt", "setsockopt");
        ctx.usesCryptoLike = containsAny(all, "aes", "sha", "md5", "hmac", "rsa", "ecdh", "chacha", "poly1305", "crypt", "bcrypt");

        addImportIf(ctx, ctx.usesMemcpyLike, "memcpy/memmove");
        addImportIf(ctx, ctx.usesStrcmpLike, "strcmp/strncmp");
        addImportIf(ctx, ctx.usesMallocFreeLike, "malloc/free");
        addImportIf(ctx, ctx.usesFileIOLike, "file_io");
        addImportIf(ctx, ctx.usesNetworkIOLike, "network_io");
        addImportIf(ctx, ctx.usesCryptoLike, "crypto");
    }

    private boolean containsAny(String haystack, String... needles) {
        for (String n : needles) {
            if (haystack.contains(n)) {
                return true;
            }
        }
        return false;
    }

    private void addImportIf(SymbolContext ctx, boolean cond, String label) {
        if (!cond) {
            return;
        }
        if (!ctx.referencedImports.contains(label)) {
            ctx.referencedImports.add(label);
        }
    }
}
