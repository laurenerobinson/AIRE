package aire.model;

public class NameSuggestion {
    public String name;
    public double confidence;
    public String reason;

    public NameSuggestion() {}
    public NameSuggestion(String name, double confidence, String reason) {
        this.name = name;
        this.confidence = confidence;
        this.reason = reason;
    }
}
