package aire;

import aire.services.ContextExtractor;
import aire.services.OllamaSuggestionProvider;
import aire.services.SuggestionProvider;
import docking.ActionContext;
import docking.action.DockingAction;
import docking.action.MenuData;
import ghidra.framework.plugintool.Plugin;
import ghidra.framework.plugintool.PluginInfo;
import ghidra.framework.plugintool.PluginTool;
import ghidra.framework.plugintool.util.PluginStatus;
import ghidra.util.Msg;

@PluginInfo(
    status = PluginStatus.STABLE,
    packageName = "A.I.R.E",
    category = "A.I.R.E",
    shortDescription = "A.I.R.E MVP proof-of-life plugin",
    description = "Dockable Suggestions panel with Refresh/Suggest/Apply + Hello menu action."
)
public class AirePlugin extends Plugin {

    private AireSuggestionsProvider provider;

    public AirePlugin(PluginTool tool) {
        super(tool);

        SuggestionProvider suggestionProvider =
                new OllamaSuggestionProvider("http://localhost:11434", "gemma3:4b");
        ContextExtractor extractor = new ContextExtractor();

        provider = new AireSuggestionsProvider(tool, extractor, suggestionProvider);

        createHelloAction();
    }

    private void createHelloAction() {
        DockingAction hello = new DockingAction("A.I.R.E Hello", getName()) {
            @Override
            public void actionPerformed(ActionContext context) {
                Msg.showInfo(this, tool.getToolFrame(), "A.I.R.E", "A.I.R.E loaded");
            }
        };

        hello.setMenuBarData(new MenuData(new String[]{"Tools", "A.I.R.E", "Hello"}, "AIRE"));
        tool.addAction(hello);
    }
}
