package aire.ui;

import aire.model.NameSuggestion;

import javax.swing.table.AbstractTableModel;
import java.util.ArrayList;
import java.util.List;

/**
 * Table model for the per-function name suggestions.
 */
public class SuggestionChoicesTableModel extends AbstractTableModel {

    private final String[] cols = {"Suggestion", "Confidence"};
    private List<NameSuggestion> suggestions = new ArrayList<>();

    public void setSuggestions(List<NameSuggestion> suggestions) {
        this.suggestions = (suggestions == null) ? new ArrayList<>() : new ArrayList<>(suggestions);
        fireTableDataChanged();
    }

    public NameSuggestion getSuggestion(int idx) {
        return (idx >= 0 && idx < suggestions.size()) ? suggestions.get(idx) : null;
    }

    @Override public int getRowCount() { return suggestions.size(); }
    @Override public int getColumnCount() { return cols.length; }
    @Override public String getColumnName(int col) { return cols[col]; }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        NameSuggestion s = suggestions.get(rowIndex);
        switch (columnIndex) {
            case 0:
                return s.name;
            case 1:
                return String.format("%.2f", s.confidence);
            default:
                return "";
        }
    }
}
