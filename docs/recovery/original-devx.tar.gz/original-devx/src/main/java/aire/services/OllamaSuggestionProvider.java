package aire.services;

import aire.model.NameSuggestion;
import aire.model.SymbolContext;
import com.google.gson.*;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

/**
 * Ollama-backed suggestion provider.
 *
 * Key improvements:
 * - Uses a richer SymbolContext (decompile, callees, strings, structure counts)
 * - Forces calibrated confidence + requires evidence bullets
 * - Keeps output strict JSON via schema
 */
public class OllamaSuggestionProvider implements SuggestionProvider {

    private final String baseUrl;   // e.g., http://localhost:11434
    private final String model;     // e.g., gemma3:4b
    private final HttpClient client;

    // Prompt stability / performance
    private static final int MAX_DECOMP_CHARS_IN_PROMPT = 2500;
    private static final int MAX_ASM_CHARS_IN_PROMPT = 500;
    private static final int MAX_LIST_ITEMS = 8;

    public OllamaSuggestionProvider(String baseUrl, String model) {
        this.baseUrl = baseUrl;
        this.model = model;
        this.client = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(10))
                .build();
    }

    @Override
    public List<NameSuggestion> suggest(SymbolContext ctx) throws Exception {
        String prompt = buildPrompt(ctx);
	
        JsonObject req = new JsonObject();
        req.addProperty("model", model);
        req.addProperty("prompt", prompt);
        req.addProperty("stream", false);

        // Make results more consistent
        JsonObject options = new JsonObject();
        options.addProperty("temperature", 0.25);
        options.addProperty("top_p", 0.9);
        options.addProperty("repeat_penalty", 1.12);
        options.addProperty("num_predict", 600);
        req.add("options", options);

        // Force a strict JSON shape for the model output
        req.add("format", buildSchema());

        HttpRequest httpReq = HttpRequest.newBuilder()
                .uri(URI.create(baseUrl + "/api/generate"))
                .timeout(Duration.ofSeconds(300))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(req.toString()))
                .build();

        HttpResponse<String> resp = client.send(httpReq, HttpResponse.BodyHandlers.ofString());
        if (resp.statusCode() != 200) {
            throw new IOException("Ollama HTTP " + resp.statusCode() + ": " + resp.body());
        }

        JsonObject root = JsonParser.parseString(resp.body()).getAsJsonObject();

        // Ollama returns a "response" field that contains our JSON string
        String responseText = root.get("response").getAsString();
        JsonObject parsed = JsonParser.parseString(responseText).getAsJsonObject();
        JsonArray suggs = parsed.getAsJsonArray("suggestions");

        List<NameSuggestion> out = new ArrayList<>();
        for (JsonElement el : suggs) {
            JsonObject o = el.getAsJsonObject();
            NameSuggestion ns = new NameSuggestion();
            ns.name = o.get("name").getAsString();
            ns.confidence = clamp01(o.get("confidence").getAsDouble());
            ns.reason = o.get("reason").getAsString();

            // Evidence bullets (optional but required by schema)
            ns.evidence.clear();
            if (o.has("evidence") && o.get("evidence").isJsonArray()) {
                for (JsonElement ev : o.getAsJsonArray("evidence")) {
                    if (!ev.isJsonNull()) {
                        String s = ev.getAsString();
                        if (s != null && !s.isBlank()) ns.evidence.add(s);
                    }
                }
            }

            // Safety: cap inflated confidence for generic names
            if (looksGeneric(ns.name) && ns.confidence > 0.70) {
                ns.confidence = 0.70;
            }
            // If evidence is missing/weak, cap confidence
            if (ns.evidence.size() < 2 && ns.confidence > 0.75) {
                ns.confidence = 0.75;
            }

            out.add(ns);
        }

        return out;
    }

    @Override
    public String getStatus() {
        return baseUrl + " | model=" + model;
    }

    private String buildPrompt(SymbolContext ctx) {
        String decomp = truncate(safe(ctx.decompiledCode), MAX_DECOMP_CHARS_IN_PROMPT);
        String asm = truncate(safe(ctx.assemblySnippet), MAX_ASM_CHARS_IN_PROMPT);

        String callees = joinLimited(ctx.callees, MAX_LIST_ITEMS);
        String strings = joinLimited(ctx.referencedStrings, MAX_LIST_ITEMS);
        String imports = joinLimited(ctx.referencedImports, MAX_LIST_ITEMS);

        StringBuilder sb = new StringBuilder();
        sb.append("You are an expert reverse engineer.\n");
        sb.append("Task: Suggest 3 candidate function names.\n");
        sb.append("Return ONLY the JSON required by the schema.\n\n");

        sb.append("Naming constraints:\n");
        sb.append("- Use snake_case\n");
        sb.append("- Prefer verb-first names (parse_, init_, handle_, decode_, validate_, read_, write_)\n");
        sb.append("- Avoid generic names unless evidence is weak\n\n");

        sb.append("Confidence calibration (critical):\n");
        sb.append("- confidence is 0.0 to 1.0 and MUST match evidence strength\n");
        sb.append("- If evidence is weak/ambiguous: confidence MUST be <= 0.55\n");
        sb.append("- If name is generic: confidence MUST be <= 0.65\n");
        sb.append("- For confidence >= 0.80 you MUST cite 2+ strong signals\n");
        sb.append("- Provide 2 to 5 evidence bullets per suggestion\n\n");

        sb.append("Context:\n");
        sb.append("functionName=").append(safe(ctx.functionName)).append("\n");
        sb.append("entryPoint=").append(safe(ctx.entryPoint)).append("\n");
        sb.append("signature=").append(safe(ctx.signature)).append("\n\n");

        sb.append("Evidence summary:\n");
        sb.append("basic_blocks=").append(ctx.basicBlockCount).append("\n");
        sb.append("instruction_count=").append(ctx.instructionCount).append("\n");
        sb.append("branches=").append(ctx.branchCount).append("\n");
        sb.append("returns=").append(ctx.returnCount).append("\n\n");

        sb.append("flags:\n");
        sb.append("usesMemcpyLike=").append(ctx.usesMemcpyLike).append("\n");
        sb.append("usesStrcmpLike=").append(ctx.usesStrcmpLike).append("\n");
        sb.append("usesMallocFreeLike=").append(ctx.usesMallocFreeLike).append("\n");
        sb.append("usesFileIOLike=").append(ctx.usesFileIOLike).append("\n");
        sb.append("usesNetworkIOLike=").append(ctx.usesNetworkIOLike).append("\n");
        sb.append("usesCryptoLike=").append(ctx.usesCryptoLike).append("\n\n");

        sb.append("callees=[").append(callees).append("]\n");
        sb.append("imports_or_behaviors=[").append(imports).append("]\n");
        sb.append("strings=[").append(strings).append("]\n\n");

        if (!decomp.isBlank()) {
            sb.append("decompiled_code:\n```c\n").append(decomp).append("\n```\n\n");
        }
        if (!asm.isBlank()) {
            sb.append("assembly_snippet:\n```\n").append(asm).append("\n```\n\n");
        }

        sb.append("Output requirements:\n");
        sb.append("- Provide exactly 3 suggestions\n");
        sb.append("- Each suggestion: name, confidence, reason, evidence[]\n");
        sb.append("- reason: ONE short sentence referencing evidence\n");
        sb.append("- evidence: 2 to 5 short bullets (APIs called, strings, behaviors, structure counts)\n");

        return sb.toString();
    }

    private String safe(String s) {
        return (s == null) ? "" : s;
    }

    private String truncate(String s, int max) {
        if (s == null) return "";
        if (s.length() <= max) return s;
        return s.substring(0, max) + "\n/* ... truncated ... */";
    }

    private String joinLimited(List<String> items, int maxItems) {
        if (items == null || items.isEmpty()) return "";
        StringBuilder sb = new StringBuilder();
        int n = Math.min(items.size(), maxItems);
        for (int i = 0; i < n; i++) {
            if (i > 0) sb.append(", ");
            sb.append(items.get(i));
        }
        if (items.size() > maxItems) sb.append(", ...");
        return sb.toString();
    }

    private double clamp01(double v) {
        if (v < 0.0) return 0.0;
        if (v > 1.0) return 1.0;
        return v;
    }

    private boolean looksGeneric(String name) {
        if (name == null) return true;
        String n = name.toLowerCase();
        return n.startsWith("sub_")
                || n.startsWith("func")
                || n.equals("process_data")
                || n.equals("do_work")
                || n.equals("handler")
                || n.equals("helper")
                || n.contains("unknown")
                || n.contains("generic");
    }

    private JsonObject buildSchema() {
        JsonObject schema = new JsonObject();
        schema.addProperty("type", "object");

        JsonObject props = new JsonObject();
        JsonObject suggestions = new JsonObject();
        suggestions.addProperty("type", "array");
        suggestions.addProperty("minItems", 3);
        suggestions.addProperty("maxItems", 3);

        JsonObject items = new JsonObject();
        items.addProperty("type", "object");

        JsonObject itemProps = new JsonObject();
        itemProps.add("name", typeString());
        itemProps.add("confidence", typeNumber());
        itemProps.add("reason", typeString());

        // evidence: array of short strings
        JsonObject evidence = new JsonObject();
        evidence.addProperty("type", "array");
        evidence.addProperty("minItems", 2);
        evidence.addProperty("maxItems", 5);
        JsonObject evidenceItems = new JsonObject();
        evidenceItems.addProperty("type", "string");
        evidence.add("items", evidenceItems);
        itemProps.add("evidence", evidence);

        items.add("properties", itemProps);

        JsonArray required = new JsonArray();
        required.add("name");
        required.add("confidence");
        required.add("reason");
        required.add("evidence");
        items.add("required", required);

        suggestions.add("items", items);
        props.add("suggestions", suggestions);
        schema.add("properties", props);

        JsonArray rootRequired = new JsonArray();
        rootRequired.add("suggestions");
        schema.add("required", rootRequired);

        return schema;
    }

    private JsonObject typeString() {
        JsonObject o = new JsonObject();
        o.addProperty("type", "string");
        return o;
    }

    private JsonObject typeNumber() {
        JsonObject o = new JsonObject();
        o.addProperty("type", "number");
        return o;
    }
}
