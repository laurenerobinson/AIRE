package aire.model;

public enum SuggestionStatus {
    NEW,
    SUGGESTED,
    APPLIED,
    REJECTED,
    ERROR
}
