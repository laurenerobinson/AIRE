#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
GHIDRA_DIR="${GHIDRA_INSTALL_DIR:-/opt/ghidra_12.0.1_PUBLIC}"
OUT_DATE="${1:-$(date +%Y%m%d)}"
MODULE_NAME="$(awk -F= '/^name=/{print $2}' "$ROOT_DIR/extension.properties" | tr -d '\r' | head -n1)"

if [[ -z "$MODULE_NAME" ]]; then
  echo "Unable to determine module name from extension.properties" >&2
  exit 1
fi

if [[ ! -d "$GHIDRA_DIR" ]]; then
  echo "Ghidra install dir not found: $GHIDRA_DIR" >&2
  echo "Set GHIDRA_INSTALL_DIR or install Ghidra at /opt/ghidra_12.0.1_PUBLIC" >&2
  exit 1
fi

TMP_BASE="/tmp/aire-package"
TMP_JAR_TREE="/tmp/aire-jar-tree"
TMP_SRC_TREE="/tmp/aire-src-tree"
TMP_CLASSES="/tmp/aire-javac"
ARTIFACT="$ROOT_DIR/dist/ghidra_12.0.1_PUBLIC_${OUT_DATE}_aire-ghidra-extension.zip"

rm -rf "$TMP_BASE" "$TMP_JAR_TREE" "$TMP_SRC_TREE" "$TMP_CLASSES"
mkdir -p "$TMP_BASE/$MODULE_NAME/lib" "$TMP_JAR_TREE" "$TMP_SRC_TREE" "$TMP_CLASSES"

echo "Compiling Java sources..."
javac -cp "$(find "$GHIDRA_DIR" -name '*.jar' | tr '\n' ':')$ROOT_DIR/lib/gson-2.10.1.jar" \
  -d "$TMP_CLASSES" \
  $(find "$ROOT_DIR/src/main/java" -name '*.java')

echo "Assembling extension jar..."
cp -R "$TMP_CLASSES/aire" "$TMP_JAR_TREE/"
cp -R "$ROOT_DIR/build/help/main/help" "$TMP_JAR_TREE/"
cp -R "$ROOT_DIR/src/main/resources/." "$TMP_JAR_TREE/"
jar cf "$TMP_BASE/$MODULE_NAME/lib/$MODULE_NAME.jar" -C "$TMP_JAR_TREE" .

echo "Assembling source zip..."
mkdir -p "$TMP_SRC_TREE/src/main"
cp -R "$ROOT_DIR/src/main/java" "$TMP_SRC_TREE/src/main/"
cp -R "$ROOT_DIR/src/main/help" "$TMP_SRC_TREE/src/main/"
cp -R "$ROOT_DIR/src/main/resources" "$TMP_SRC_TREE/src/main/"
(cd "$TMP_SRC_TREE" && zip -qr "$TMP_BASE/$MODULE_NAME/lib/$MODULE_NAME-src.zip" src)

echo "Copying extension metadata..."
cp "$ROOT_DIR/extension.properties" "$TMP_BASE/$MODULE_NAME/"
cp "$ROOT_DIR/Module.manifest" "$TMP_BASE/$MODULE_NAME/"
cp -R "$ROOT_DIR/data" "$TMP_BASE/$MODULE_NAME/"
cp -R "$ROOT_DIR/ghidra_scripts" "$TMP_BASE/$MODULE_NAME/"
cp -R "$ROOT_DIR/os" "$TMP_BASE/$MODULE_NAME/"
cp "$ROOT_DIR/README.md" "$TMP_BASE/$MODULE_NAME/"
cp "$ROOT_DIR/lib/README.txt" "$TMP_BASE/$MODULE_NAME/lib/"
cp "$ROOT_DIR/lib/gson-2.10.1.jar" "$TMP_BASE/$MODULE_NAME/lib/"

mkdir -p "$ROOT_DIR/dist"
echo "Packaging final extension zip..."
rm -f "$ARTIFACT"
(cd "$TMP_BASE" && zip -qr "$ARTIFACT" "$MODULE_NAME")

echo "Built artifact:"
echo "$ARTIFACT"
